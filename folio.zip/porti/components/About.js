import React from 'react';
import Typical from 'react-typical'
const About = () => {
  return (
    <div className='container'>
        <div className='row' id="About">
            <div className='col-12 col-md-6'>
            
                <div className='image'>
                 <img src="./image/sr.jpg" height="300" width="300"/>   
                </div>
            </div><br/>
            <div className='col-12 col-md-6'>
              <div className='scroll'>
            <Typical
        steps={['SANDEEP',1000, 'FRONTEND DEVELOPER!',1000,' WEB DEVELOPER.',1000]}
        loop={Infinity}
        wrapper="p"
      />
      </div>  
                <div className='bannerrole'>
                
                    <h1 className='HEADING'>Have been working as an UI developer from two years in <a href="https://www.quest-global.com">quest<br/>-global</a></h1>
                </div>
                <div className='col-12'>
                    <ol>
                        <img src="./image/fb.png" height="50px" width="50px"/>
                       
                        <img src="./image/lk.png" height="50px" width="50px"/>
                       
                        <img src="./image/ig.jpg" height="50px" width="50px"/>
                        
                        <img src="./image/tw.png" height="50px" width="50px"/>
                    </ol>
                </div>
            </div>
        </div>
      
    </div>
  )
}

export default About

