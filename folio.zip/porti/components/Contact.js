import React,{useState} from 'react';
function App() {
  const [input,setInput]=useState('')
  const [password,setpassword]=useState('')
  const [todo,setTodo]=useState([])
  const onUserIdChange=(e)=>{
 setInput(e.target.value)
 console.log(input)

  }
const onPasswordChange=(f)=>{
  setpassword(f.target.value)
  console.log(password)
}
const onLoginChange=(g)=>{
   setTodo([...todo,{
    title:input
    
  }])

}
const loginHandling=(event)=>{
event.preventDefault();
console.log(event)
console.log(input,password)

}
  return (
    <div className="App">
       <h1 className='contact_heading'>I Look forward to hear from you</h1> 
      <div className="row" id="Contact"> 
        <div className="column_one">
          <img src="./image/h.jpg"  height="300px" width="400px" />
        
        </div>
        <div className="column_two">
          <div className="login_page">
            
            <form onSubmit={loginHandling}>
              <div>
              <label>Email Address</label><br/>
              <input
                required
                type="text"
                
              
                onChange={onUserIdChange}
              />
              </div>
              <br />
              <div>
                <label>Comments</label><br/>
              <input
                required
                type="text"
               
               
                onChange={onPasswordChange}
              />
              </div>
              <br />
              <button>Send Email</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;


