import React from 'react'

const Footer = () => {
  return (
    <div id="Footer">
      <footer className='bg-dark'>
        < div className='cointainer main-cointainer mx-auto text-center'>
            <ul className='navbar-nav d-block text-center foo1 p-0'>
                <li className='nav-link1'>Portfolio</li>
                <li className='nav-link1'>Release Date :28/7/2022</li>
                <li className='nav-link1'>Version:v3</li>
                <li className='nav-link1'>Copyright 2022&nbsp;Sandeep</li>
            </ul>
        </div>
      </footer>
    </div>
  )
}

export default Footer
