import React from 'react'

const Education = () => {
  return (
    <div className='APP'>
      <h1>Education</h1>
    <div className='card' id="Education">
<div class="third">
<img src="./image/school.jpg"/>
  <h1 className='color'>School</h1>
   <h2 className='color'>St Mark's E/M High School</h2>
   <p className='para'>Passedout in the year 2021 with percentage/CGPA of 88</p>
      </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<div class="third"> 
<img src="./image/school.jpg"/>
<h1 className='color'>Intermediate</h1> 
<h2 className='color'>Narayana Junior College</h2>
<p className='para'>Passedout in the year 2021 with percentage/CGPA of 88</p>
</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<div class="third"> 
<img src="./image/school.jpg"/>
<h1 className='color' >Degree</h1>
<h2 className='color'>Presidency university</h2>
<p className='para'>Passedout in the year 2021 with percentage/CGPA of 88</p>
 </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>
    </div>
  )
}

export default Education
