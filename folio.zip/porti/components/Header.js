import * as React from 'react';
import PropTypes from 'prop-types';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { Link, Element, Events, animateScroll as scroll, scrollSpy, scroller } from 'react-scroll'



const drawerWidth = 240;
const navItems = ['About', 'Education', 'Projects','Contact','Footer',];

function DrawerAppBar(props) {


  const handleScroll =()=>{
    console.log('iiii');
    window.scroll({top:0,behavior: 'smooth'});
  }


  return (
    <Box sx={{ display: "flex" }}>
      <AppBar component="nav">
        <Toolbar>
          
          <Box sx={{ display: { xs: "none", sm: "block" } }}>
            
            <Button sx={{ color: "#fff" }}>
              <Link
                activeClass="active"
                spy={true}
                smooth={true}
                offset={50}
                duration={1000}
                to="Education"
              >
                Education
              </Link>
            </Button>

            <Button sx={{ color: "#fff" }}>
              <Link
                activeClass="active"
                spy={true}
                smooth={true}
                offset={50}
                duration={1500}
                to="Projects"
              >
                Projects
              </Link>
            </Button>

            <Button sx={{ color: "#fff" }}>
              <Link
                activeClass="active"
                spy={true}
                smooth={true}
                offset={50}
                duration={1000}
                to="Contact"
              >
                Contact
              </Link>
            </Button>


            <Button
              sx={{ color: "#fff" }}
              onClick={() => handleScroll()}
            >
              About
            </Button>
            <Button
              sx={{ color: "#fff" }}
              // onClick={() => handleScroll()}
            >
              <Link
                activeClass="active"
                spy={true}
                smooth={true}
                offset={50}
                duration={1000}
                to="Footer"
              >
              Footer
              </Link>
            </Button>

          </Box>
        </Toolbar>
      </AppBar>
      
    </Box>
  );
}

export default DrawerAppBar;
