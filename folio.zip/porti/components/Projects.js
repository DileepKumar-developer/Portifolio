import React from 'react'
const Projects = () => {
  return (
    <div className='project' id="Projects">
      <h1>Projects I worked on</h1>
      <h6>Involved in various projects for different clients which put forward many challenges and helped me learn things</h6>
<div className='know'>
<img src="./image/a.png" height="100px" width="100px"/>
<img src="./image/b.jpg"height="100px" width="100px"/>
<img src="./image/c.png"height="100px" width="100px"/>
<img src="./image/d.png"height="100px" width="100px"/>
<img src="./image/e.png"height="100px" width="100px"/>
<img src="./image/f.png"height="100px" width="100px"/>
<img src="./image/g.png"height="100px" width="100px"/>
</div><br/>
<div className='one'>
  <h1 className='projectname'>FarmFunding</h1>
  <h2 className='workon' >Agrideck</h2>
  <p>HERE Agrideck works on mainly two views.<br/>
    1.FF view
    2.Branch View
  </p>
   <h1>project overview</h1>
<p>The farmer funding business have 3000 +plus manpower , O ut of which there are 800 bank staff &
rest are Rural Executives who caters to the credit requirement of the farmers. Farmer funding dept
have 4 L+ customers which are being facilitated by RMs & RE.
T hrough this Project, we propose to enhance data/MIS availability of sales team at their ease along
with reduce the manual work done at co level by introducing FF RM app. </p>

                </div>
                <div className='two'>
    <img src="./image/agrideck2.png" height="200px" width="600px"/><br/>
    <img src="./image/agrideck1.png" height="200px" width="600px"/><br/>
</div><br/><br/><br/><br/>
<br/>
<div className='clg_project'>
<h1>Garden Monitoring and Controlling system for balcony and Terrace of Apartment in Metro city-A Smart Solution</h1>
<h2>Based on IOT concept smart gardening project is implemented ,with iot sensors and electromechanical relay module is used to control the process automatically sensors are temperature and humidity,moisture and water level and ldr sensor used to monitor the sensor readings and based on readings automatically controlling fan,lights,waterpump,buzzer using relay moduleand android application used for monitoring the sensordata to blynk cloud and the blynk app with esp32 controller programming used embedded c.</h2>
</div>
</div> 
  )
}

export default Projects
